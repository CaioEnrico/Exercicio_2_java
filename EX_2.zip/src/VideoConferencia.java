public interface VideoConferencia {

    public void fazStreaming();
}