public interface Compartilhamento {

    public void compartilhar();
}